<style>
    <?php
    // PHP code for dynamic CSS properties
    echo "@import url('https://fonts.googleapis.com/css?family=Lato&display=swap');";

    echo "* {
        box-sizing: border-box;
    }";

    echo ".main-logo{
        width:90%;
        max-width: 150px;
    }";

    echo "body {
        background-color: #000000;
        color: #fff;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        font-family: 'Lato', sans-serif;
        margin: 0;
    }";

    echo ".movie-container {
        margin: 20px 0;
    }";

    echo ".movie-container select {
        background-color: #fff;
        border: 0;
        border-radius: 5px;
        font-size: 14px;
        margin-left: 10px;
        padding: 5px 15px 5px 15px;
        -moz-appearance: none;
        -webkit-appearance: none;
        appearance: none;
    }";

    echo ".container {
        perspective: 1000px;
        margin-bottom: 30px;
    }";

    echo ".seat {
        background-color: #444451;
        height: 12px;
        width: 15px;
        margin: 3px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
    }";

    echo ".seat.selected {
        background-color: #6feaf6;
    }";

    echo ".seat.occupied {
        background-color: #fff;
    }";

    echo ".seat:nth-of-type(2) {
        margin-right: 18px;
    }";

    echo ".seat:nth-last-of-type(2) {
        margin-left: 18px;
    }";

    echo ".seat:not(.occupied):hover {
        cursor: pointer;
        transform: scale(1.2);
    }";

    echo ".showcase .seat:not(.occupied):hover {
        cursor: default;
        transform: scale(1);
    }";

    echo ".showcase {
        background: rgba(0, 0, 0, 0.1);
        padding: 5px 10px;
        border-radius: 5px;
        color: #777;
        list-style-type: none;
        display: flex;
        justify-content: space-between;
    }";

    echo ".showcase li {
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 10px;
    }";

    echo ".showcase li small {
        margin-left: 2px;
    }";

    echo ".row {
        display: flex;
    }";

    echo ".screen {
        background-color: #fff;
        height: 70px;
        width: 100%;
        margin: 15px 0;
        transform: rotateX(-45deg);
        box-shadow: 0 3px 10px rgba(255, 255, 255, 0.7);
    }";

    echo "p.text {
        margin: 5px 0;
    }";

    echo "p.text span {
        color: #6feaf6;
    }";

    echo ".status{
        color:white;
    }";

    echo ".nav-link{
        color: white !important;
        font-weight: 500 !important;
    }";

    echo ".btn-home{
        background-color: #E50914;
        border: 1px solid #E50914;
        padding: .6em 2em;
        border-radius: 10px;
        font-size: 1em;
        font-weight: 600;
        cursor: pointer;
    }";

    echo ".btn-home:active{
        border: 0px solid #E50914;
    }";
    ?>
</style>