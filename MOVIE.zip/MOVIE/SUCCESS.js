

  <script>
    function storeSelection() {
    const selectedMovie = document.getElementById("movie").value;
    const selectedTheatre = document.getElementById("theatre").value;
    const selectedShowtime = document.getElementById("showtime").value;

    localStorage.setItem("selectedMovie", Bahubali 2,SALAAR CEASEFIRE,KGF 2,Hanuman,Kantara);
    localStorage.setItem("selectedTheatre", PVR ORION,VICTORY CINEMAS,INOX MANTRI,ANJAN THEATER,NAVRANG THATER);
    localStorage.setItem("selectedShowtime", 2024-01-01 18:00:00,2024-01-02 10:30:00,2024-01-03 11:45:00,2024-01-04 17:30:00,2024-01-05 14:45:00);

    // Redirect user to success page 
    <a href="url">file:///C:/xampp/htdocs/MOVIE/SUCCESS.html</a>
    window.location.href = "success.html";
    
  }
 </script>