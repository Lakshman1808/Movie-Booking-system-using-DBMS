<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "MOVIE_BOOKING";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Retrieve data from AJAX request
$data = json_decode(file_get_contents('php://input'), true);

// Process data and insert into database (example)
$selectedSeats = $data['selectedSeats'];
$movie = $data['movie'];
$theatre = $data['theatre'];
$showtime = $data['showtime'];
$total = $data['total'];

// You should sanitize and validate input data before inserting into the database to prevent SQL injection

// Example SQL query to insert data into a table
$sql = "INSERT INTO bookings (selected_seats, movie, theatre, showtime, total) VALUES ('$movie', '$theatre', '$showtime', '$total')";

if ($conn->query($sql) === TRUE) {
$booking_id = $conn->insert_id; 
  header("Location: BOOKING.html?booking_id=$booking_id&movie=$movie&theatre=$theatre&showtime=$showtime");
  exit();
  echo "Booking successful!";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Movie Seat Booking</title>
    <link rel="stylesheet" href="style.css">
    
    <style>
      
    </style>
  </head>
  <body>
    
    <div>
      <img class="main-logo" src="https://img.freepik.com/premium-vector/movie-ticket-logo-template-design_20029-891.jpg"/>
    </div>

     
    <div class="movie-container">
      <label style="font-size: 1em;">Pick a movie:</label>
      <select id="movie">
        <option value="300">Bahubali 2</option>
        <option value="275">SALAAR CEASEFIRE</option>
        <option value="250">KGF 2</option>
        <option value="225">Hanuman</option>
        <option value="200">Kantara</option>
        
        
      </select>
    </div>
    
   <div class="theatre-container">
      <label style="font-size: 1em;">Pick a theatre:</label>
      <select id="theatre">
        <option value="300">PVR ORION</option>
        <option value="275">VICTORY CINEMAS</option>
        <option value="250">INOX MANTRI</option>
        <option value="225">ANJAN THEATER</option>
        <option value="200">NAVRANG THEATER</option>
                

      </select>
    </div>

  <div class="showtimes-container">
      <label style="font-size: 1em;">Pick a showtime:</label>
      <select id="showtime">
        <option value="300">2024-01-01 18:00:00</option>
        <option value="275">2024-01-02 10:30:00</option>
        <option value="250">2024-01-03 11:45:00</option>
        <option value="225">2024-01-04 17:30:00</option>
        <option value="200">2024-01-05 14:45:00</option>
              

      </select>
    </div>

    <ul class="showcase">
      <li>
        <div id="seat" class="seat"></div>
        <small class="status" style="font-size: 1em;">N/A</small>
      </li>
      <li>
        <div id="seat" class="seat selected"></div>
        <small class="status" style="font-size: 1em;">Selected</small>
      </li>
      <li>
        <div id="seat" class="seat occupied"></div>
        <small class="status" style="font-size: 1em;">Occupied</small>
      </li>
    </ul>

    <div class="container">
      <div class="screen"></div>

      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
      </div>
      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
      </div>
      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat occupied"></div>
      </div>
      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
      </div>
      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
      </div>
      <div class="row">
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat occupied"></div>
        <div id="seat" class="seat"></div>
      </div>
    </div>

    <p class="text" style="font-size: 1em;margin:0px 0px 15px 0px">
      You have selected <span id="count">0</span> seats for a price of Rs<span
        id="total"
        >0</span
      >
    </p>

    <a href="./i1.html">
      <button class="btn-home">
        Home
      </button>
    </a>
    <a href="SUCCESS.html">
      <button class="btn-success">
        Book
      </button>
    </a>
    

    <script>
     
      var count=0;
      var seats=document.getElementsByClassName("seat");
      for(var i=0;i<seats.length;i++){
        var item=seats[i];
        
        item.addEventListener("click",(event)=>{
          var price= document.getElementById("movie").value;

          if (!event.target.classList.contains('occupied') && !event.target.classList.contains('selected') ){
          count++;
          
          var total=count*price;
          event.target.classList.add("selected");
          document.getElementById("count").innerText=count;
          document.getElementById("total").innerText=total;

          }
        })
      }
    </script>

    <script src="booking_logic.js"></script>

<script>
   // Function to send seat booking data to server
function bookSeats() {
  var selectedSeats = document.querySelectorAll('.seat.selected');
  var movie = document.getElementById("movie").value;
  var theatre = document.getElementById("theatre").value;
  var showtime = document.getElementById("showtime").value;
  var total = document.getElementById("total").innerText;

  // Prepare data to send to server
  var data = {
    selectedSeats: selectedSeats.length,
    movie: movie,
    theatre: theatre,
    showtime: showtime,
    total: total
  };

  // Send data to server using AJAX
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "BOOKING_PROCESS.php", true); // <-- This line
  xhr.setRequestHeader("Content-Type", "application/json");
  xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
      // Handle response from server
      console.log(xhr.responseText);
      // Redirect or show success message
      window.location.href = "SUCCESS.html";
    }
  };
  xhr.send(JSON.stringify(data));
}

</script>

<button onclick="bookSeats()">Book Seats</button>



  </body>
</html>