<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style-home.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet">
</head>
<body style="background-color: black;">
    <nav class="navbar navbar-expand-lg navbar-light bg-custom">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="https://img.freepik.com/premium-vector/movie-ticket-logo-template-design_20029-891.jpg" style="width:80px"/>
            </a>

            <div >
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="./i1.html">Home</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div>
        <h4 style="color: #E50914; font-weight: 700;" class="text-center my-4">Now Playing</h4>
    </div>
    <div class="btn-collection-playing my-4">
        <?php
        // Here you can include PHP logic if needed
        ?>
        <a href="book.html">
            <button class="btn btn-custom">
                Buy Ticket
            </button>
        </a>
    </div>
    
    <div class="container">
        <div class="row justify-content-around align-items-center">
            <img src="https://img1.hotstarext.com/image/upload/f_auto,t_vl/sources/r1/cms/prod/5085/635085-v" class="img-card col-lg-4 col-md-6 col-sm-12 col-12" style="max-width: 250px;width:90%"/>
    
            <img src="https://i.pinimg.com/originals/66/5c/96/665c96079039ef129edc91a6123388e0.jpg" class="img-card col-lg-4 col-md-6 col-sm-12 col-12" style="max-width: 250px;width:90%"/>
    
            <img src="https://m.media-amazon.com/images/S/pv-target-images/4f131598e680ba4022427a07d7ca927b76890253eb922a35d4a7de9ae9011488.jpg" class="img-card col-lg-4 col-md-6 col-sm-12 col-12" style="max-width: 250px;width:90%"/>
            
            <img src="https://images.filmibeat.com/ph-big/2022/11/hanuman-2023_166902346020.jpg" class="img-card col-lg-4 col-md-6 col-sm-12 col-12" style="max-width: 250px;width:90%"/>
            <img src="https://m.media-amazon.com/images/M/MV5BY2NkYmVlNjItZjBjMi00ZDc3LThmNzYtNmE0ZmE1ZGNjMTQ5XkEyXkFqcGdeQXVyMTUzNTgzNzM0._V1_.jpg" class="img-card col-lg-4 col-md-6 col-sm-12 col-12" style="max-width: 250px;width:90%"/>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
</body>
</html>